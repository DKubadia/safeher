import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { BrowserRouter } from 'react-router-dom';
import { ConversationProvider } from '@elevenlabs/react';
import reportWebVitals from './reportWebVitals';

const AGENT_ID = "agent_2801k4c88aaffanv3kvjc8sksxrm";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <ConversationProvider agentId={AGENT_ID}>
        <App />
      </ConversationProvider>
    </BrowserRouter>
  </React.StrictMode>
);

reportWebVitals();
